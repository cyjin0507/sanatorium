const log = document.querySelector('.event-log');

document.querySelector('#xhr').addEventListener('click', ()=> {
    log.textContent = '';
    const xhr = new XMLHttpRequest();
    xhr.addEventListener('loadend', ()=> {
        log.textContent = `${log.textContent}요청 상태정보 : ${xhr.status}`;
    })

    xhr.open('GET', 'https://raw.githubusercontent.com/mdn/content/main/files/en-us/_wikihistory.json');
    xhr.send()
    log.textContent = `${log.textContent}요청을 시작했습니다.`
})

document.querySelector('#reload').addEventListener('click', ()=> {
    log.textContent = '';
    document.location.reload();
})