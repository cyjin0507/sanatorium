const log = document.querySelector('.event-log');

document.querySelector('#xhr').addEventListener('click', ()=> {
    log.textContent = '';
    const xhr = new XMLHttpRequest();
    xhr.addEventListener('loadend', ()=> {
        log.textContent = `${log.textContent}요청 상태정보 : ${xhr.status}`

        if(xhr.status == 200) {
            Process();
        }
    })

    xhr.open('GET', 'https://raw.githubusercontent.com/mdn/content/main/files/en-us/_wikihistory.json')
        xhr.send();
        log.textContent = `${log.textContent}요청을 시작했습니다.\n`

        function Process() {
            let dat = xhr.responseText;

            let parseDat = JSON.parse(dat);

            let str = "";
            for(var i=0; i<parseDat.Games.contributors.length; i++) {
                str += parseDat.Games.contributors[i] + "<br>"
            }

            str += `<br>게임 기여자 : ${parseDat.Games.contributors.length}인`
            document.querySelector('.parse-dat').innerHTML = str;
        }
})